//user, userConnection, connection model
var connection = require('../models/connection.model');
var userConnection = require('../models/userConnection.model');
var user = require('../models/user.model');
const { validationResult } = require('express-validator');

exports.test = function (req, res) {
    res.send('Good to go!');
};
// create connection
exports.createConn = function (req, res) {
    let conn = new connection();
    conn.connectionId = "B03";
    conn.name = "ITIS Cryptos";
    conn.topic = "Education";
    conn.details = "Online";
    conn.datetime = "Monday";
    conn.location = "Woodward Hall";
    conn.save(function (err, data) {
        if (err) {
            console.log({ "Error": "Fatal Error" });
        } else {
            console.log("Data Saved ");
            connection.find({}, function (err, docs) {
                if (err)
                    console.log(err);
                else
                    res.render('savedConnections', { data: docs });
            });
        }
    })
};
// login function
exports.login = function (req, res) {
    if (req.session.userName) {
        res.app.locals.loginUser = req.session.userName;

        connection.find({}, function (err, docs) {
            if (err)
                console.log(err);
            else
                res.render('savedConnections', { data: docs });
        });
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};

// My Meetups Function
exports.mymeetups = function (req, res) {
    if (req.session.userName) {
        res.app.locals.loginUser = req.session.userName;
        connection.find({}, function (err, docs) {
            if (err)
                console.log(err);
            else
                res.render('savedConnections', { data: docs });
        });
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};

// Delete session
exports.delete = function (req, res) {
    const connId = req.params.id;
    connection.deleteOne({ connectionId: connId }, function (err) {
        if (err)
            console.log(err);
        else {
            connection.find({}, function (err, docs) {
                if (err)
                    console.log(err);
                else
                    res.render('savedConnections', { data: docs });
            });
        }
    });
};

// Controller saves user entered data
exports.connection_save = function (req, res) {

    //check validate data
    const result = validationResult(req);
    var errors = result.errors;
    for (var key in errors) {
        console.log(errors[key].value);
    }
    if (!result.isEmpty()) {
        //response validates data to register.ejs
        res.render('newConnections', {
            errors: errors
        })
    }

    if (req.session.userName) {
        let conn = new connection();
        conn.connectionId = req.body.id;
        conn.name = req.body.name;
        conn.topic = req.body.topic;
        conn.details = req.body.details;
        conn.datetime = req.datetime;
        conn.location = req.body.location;
        conn.save(function (err, data) {
            if (err) {
                console.log({ "Error": "Fatal Error" });
            } else {
                console.log("==== Data Saved ====");
                res.app.locals.loginUser = req.session.userName;
                connection.find({}, function (err, docs) {
                    if (err)
                        console.log(err);
                    else
                        res.render('savedConnections', { data: docs });
                });
                // res.render('connections', { data: data });
            }
        })
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};
exports.user_connection_save = function (req, res) {
    if (req.session.userName) {
        const connId = req.query.id;
        const rsvp = req.query.rsvp;

        connection.findOne({ connectionId: connId }, function (err, conn) {
            if (err)
                console.log(err);
            else {
                if (!conn) {
                    console.log({ message: "No record found", STATUS: false })
                } else {
                    let userConn = new userConnection();
                    userConn.connection = conn;
                    userConn.rsvp = rsvp;
                    userConn.save(function (err, data) {
                        if (err) {
                            console.log({ "Error": "Fatal Error" });
                        } else {
                            console.log("Data Saved");
                            connection.find({}, function (err, docs) {
                                if (err)
                                    console.log(err);
                                else
                                    res.render('savedConnections', { data: docs });
                            });
                        }
                    })
                }
            }
        });
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};

// Connection controller function
exports.connection = function (req, res) {
    if (req.session.userName) {
        res.app.locals.loginUser = req.session.userName;
        let connId = req.query.id;
        connection.findOne({ connectionId: connId }, function (err, conn) {
            if (err)
                console.log(err);
            else {
                if (!conn) {
                    console.log({ message: "No record found", STATUS: false })
                } else {
                    res.render('connection', { data: conn });
                }
            }
        });
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};
// view all users
exports.allusers = function (req, res) {
    if (req.session.userName) {
        res.app.locals.loginUser = req.session.userName;

        user.find({}, function (err, docs) {
            if (err)
                console.log(err);
            else
                res.render('viewAllUsers', { data: docs });
        });
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};
// delete user
exports.deleteuser = function (req, res) {
    if (req.session.userName) {
        res.app.locals.loginUser = req.session.userName;

        const usrId = req.params.id;
        user.deleteOne({ _id: usrId }, function (err) {
            if (err)
                console.log(err);
            else {
                user.find({}, function (err, docs) {
                    if (err)
                        console.log(err);
                    else
                        res.render('viewAllUsers', { data: docs });
                });
            }
        });
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};
// view user detail
exports.userDetail = function (req, res) {
    if (req.session.userName) {
        res.app.locals.loginUser = req.session.userName;
        let userId = req.query.id;
        user.findOne({ _id: userId }, function (err, userDet) {
            if (err)
                console.log(err);
            else {
                if (!userDet) {
                    console.log({ message: "No record found", STATUS: false })
                } else {
                    res.render('userDet', { data: userDet });
                }
            }
        });
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};

// Group data by topic
exports.groupBy = function (xs, key) {
    return xs.reduce(function (rv, x) {
        (rv[x[key]] = rv[x[key]] || []).push(x);
        return rv;
    }, {});
};
