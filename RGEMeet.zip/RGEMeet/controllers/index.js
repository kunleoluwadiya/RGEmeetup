const connectionDB = require('../data/connectionDB');
const { validationResult } = require('express-validator');
var sess;

//user and connection models
var user = require('../models/user.model');
var connection = require('../models/connection.model');

exports.test = function (req, res) {
    res.send('Good to go!');
};

exports.index = function (req, res) {
    req.session.savedConnections = connectionDB.getConnections();
    res.render('index');
};

// About Controller
exports.about = function (req, res) {
    res.render('about');
};

// Contact Controller
exports.contact = function (req, res) {
    res.render('contact');
};

// Controller will delete sessions and cookies
exports.logout = function (req, res) {
    req.session.destroy((err) => {
        if (err) {
            return console.log(err);
        }
        res.app.locals.loginUser = '';
        res.clearCookie('my.connect.id');
        res.redirect('/');
    });
};

// Controller will diplay all connections
exports.connections = function (req, res) {
    if (req.session.userName) {
        res.app.locals.loginUser = req.session.userName;
        connection.find({}, function (err, docs) {
            if (err)
                console.log(err);
            else
                res.render('savedConnections', { data: docs });
        });
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};

// Controller will display connection by id
exports.connection = function (req, res) {
    if (req.session.userName) {
        let id = req.query.id;

        let session = req.session;
        let data = session.savedConnections.filter((item) => item.connectionId === id);

        res.app.locals.loginUser = req.session.userName;
        res.render('connection', { data: data });
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};

// New Connections Controller
exports.add_new_connection = function (req, res) {
    if (req.session.userName) {
        res.app.locals.loginUser = req.session.userName;
        res.render('newConnections');
    } else {
        res.render('login', { error: true, message: "Please Login First" });
    }
};

exports.signup_user = function (req, res) {
    res.render('signup');
};
exports.registered = function (req, res) {
    //check validate data
    const result = validationResult(req);
    var errors = result.errors;
    for (var key in errors) {
        console.log(errors[key].value);
    }
    if (!result.isEmpty()) {
        //res validates data to signup.ejs
        res.render('signup', {
            errors: errors
        })
    }

    let usr = new user();

    usr.firstName = req.body.firstName;
    usr.lastName = req.body.lastName;
    usr.emailAddress = req.body.emailAddress;
    usr.address1 = req.body.address1;
    usr.address2 = req.body.address2;
    usr.city = req.body.city;
    usr.state = req.body.state;
    usr.zipCode = req.body.zipCode;
    usr.country = req.body.country;
    usr.password = req.body.password;

    user.findOne({ emailAddress: req.body.emailAddress }, function (err, data) {
        if (err)
            console.log(err);
        else {
            if (!data) {
                usr.save(function (err, data) {
                    if (err) {
                        console.log({ "Error": "Fatal Error" });
                    } else {
                        console.log("User has been registered ", data);
                        res.render('');
                    }
                })
            } else {
                console.log({ message: "This email is already in use", STATUS: false })
            }
        }
    });
};

exports.login_user = function (req, res) {
    res.render('login', { error: false, message: "Email and Password not matched" });
};

// sign in controller
exports.signIn = function (req, res) {

    //check validate data
    const result = validationResult(req);
    var errors = result.errors;
    for (var key in errors) {
        console.log(errors[key].value);
    }
    if (!result.isEmpty()) {
        //response validate data to login.ejs
        res.render('login', {
            errors: errors
        })
    }

    sess = req.session;
    let email = req.body.email;
    let password = req.body.password;

    if (!email || !password) {
        res.render('login', { error: true, message: "Please fill all fields" });
    }

    user.findOne({ emailAddress: email, password: password }, function (err, data) {
        if (err)
            console.log(err);
        else {
            if (!data) {
                res.render('login', { error: true, message: "Email and Password do not match" });
            } else {
                let userName = data.firstName + " " + data.lastName;
                req.session.userName = userName;
                res.app.locals.loginUser = req.session.userName;

                connection.find({}, function (err, docs) {
                    if (err)
                        console.log(err);
                    else
                        res.render('savedConnections', { data: docs, userName: userName });
                });
            }
        }
    });
};