const { UserConnection } = require('../models/userConnection');

let userConnection = [

    new UserConnection("A01", "A-Team", 'TV/Film', 'Physical', 'Tuesday', 'Cato Hall', 'MAYBE'),
    new UserConnection("A02", "Cosby Show", 'TV/Film', 'Physical', 'Wednesday', 'Woodward Hall', 'YES')
];


module.exports.getUserConnections = function () {
    return userConnection;
};

module.exports.getUserConnection = function (id) {
    return this.connection.filter((obj) => id !== obj.connectionId);

};
