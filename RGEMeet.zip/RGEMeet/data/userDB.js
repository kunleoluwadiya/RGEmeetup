const { User } = require('../models/User');

const userDB = [

    new User("CU01", "Frank", 'White', 'frankwhite@uncc.edu', '123 Main St',
        'Apt 4', 'Charlotte', 'NC', 28211, 'USA'),
    new User("CU02", "Peegy", 'Sanya', 'pseggy@uncc.edu', '456 Area Way',
        'Apt S', 'Greensboro', 'NC', 28371, 'USA')

];



module.exports.getUsers = () => { return userDB; };

module.exports.getRandomUser = () => {
    const randIndex = Math.floor(Math.random() * userDB.length);
    return userDB[randIndex];
};

