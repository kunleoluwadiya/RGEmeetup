
const { Connection } = require('./../models/connection');

let connection = [
    new Connection("A01", "A-Team", 'TV/Film', 'Physical', 'Tuesday', 'Cato Hall'),
    new Connection("A02", "Cosby Show", 'TV/Film', 'Physical', 'Wednesday', 'Woodward Hall'),
    new Connection("A03", "GOT Thronies", 'TV/Film', 'Physical', 'Thursday', 'Student Union'),
    new Connection("B01", "ITIS 5166", 'Education', 'Online', 'Friday', 'Cato Hall'),
    new Connection("B02", "ITIS 4199", 'Education', 'Online', 'Wednesday', 'Cooper Hall'),
    new Connection("B03", "ITIS Cryptos", 'Education', 'Online', 'Monday', 'Woodward Hall'),
];


module.exports.getConnections = function () {
    return connection;
};

module.exports.getConnection = function (id) {
    return this.connection.filter((obj) => id !== obj.connectionId);

};
 



