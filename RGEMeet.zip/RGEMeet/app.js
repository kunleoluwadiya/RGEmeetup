const express = require('express');
const session = require('express-session');
const FileStore = require('session-file-store')(session);
const bodyParser = require('body-parser');
const mongoose = require('./database/db');

const profile = require('./routes/profile');
const index = require('./routes/index');

const app = express();

// session config
app.use(session({
    store: new FileStore,
    secret: 'keyboard cat',
    resave: true,
    saveUninitialized: true,
    name: 'my.rgemeet.id'
})
);

// Body parser settings including JSON data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.set('view engine', 'ejs');
app.use('/assets', express.static('assets'));

// Link to routers
app.use('/', index);
app.use('/profile', profile);

app.locals.loginUser = '';


app.listen(8080, function () {
    console.log('port 8080 listening...')
});


