// User Profile Class
class UserProfile extends Array {

    userId;
    userConnection: [UserConnection];

    constructor(userId, userConnection: [UserConnection]) {
        super();
        this.userId = userId;
        this.userConnection = userConnection;
    }

    addConnection(connection){
        this.userConnection.push(connection)
    }

    removeConnection(connection){
        this.userConnection.filter((item) => item.connectionId === connection.connectionId)
    }

    updateConnection(userConnection){
        const index = this.userConnection.findIndex((item) => item.connectionId === userConnection.connectionId);
        this.userConnection[index] = userConnection;
    }

    getConnections(){
        return this.userConnection;
    }

    emptyProfile(){
        this.userConnection = [];
    }
}



