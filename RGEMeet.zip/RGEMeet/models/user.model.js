var mongoose = require('mongoose');
var Schema = mongoose.Schema;
const ObjectId = Schema.ObjectId;

var userSchema = new Schema({
    userId: ObjectId,
    firstName: { type: String },
    lastName: { type: String },
    emailAddress: { type: String },
    password: { type: String },
    address1: { type: String },
    address2: { type: String },
    city: { type: String },
    state: { type: String },
    zipCode: { type: String },
    country: { type: String }
});

module.exports = mongoose.model('user', userSchema);