var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var userConnectionSchema = new Schema({
    connection: { type: Object },
    rsvp: { type: String }
});

module.exports = mongoose.model('userConnection', userConnectionSchema);