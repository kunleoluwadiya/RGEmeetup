// Connection Class
class Connection {
    constructor(connectionId, name, topic, details, datetime, location) {
        this.connectionId = connectionId;
        this.name = name;
        this.topic = topic;
        this.details = details;
        this.datetime = datetime;
        this.location = location;
    }
}

module.exports = {
    Connection
};


