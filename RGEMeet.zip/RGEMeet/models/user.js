// User Class
class User {
    constructor(userId, firstName, lastName, email, address1, address2, city, state, zipCode, country) {

        this.userId = userId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = email;
        this.address1 = address1;
        this.address2 = address2;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
        this.country = country;
    }
}

module.exports = {
    User
};
