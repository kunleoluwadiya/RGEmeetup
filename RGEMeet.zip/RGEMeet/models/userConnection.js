const { Connection } = require('../models/connection')

// User Connection Class
class UserConnection extends Connection{
    constructor(connectionId, name, topic, details, datetime, location, rsvp) {
        super(connectionId, name, topic, details, datetime, location);
        this.rsvp = rsvp;
    }

}


module.exports = {
    UserConnection
};
