var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var connectionSchema = new Schema({
    connectionId: { type: String },
    name: { type: String },
    topic: { type: String },
    details: { type: String },
    datetime: { type: String },
    location: { type: String },
});

module.exports = mongoose.model('connection', connectionSchema);