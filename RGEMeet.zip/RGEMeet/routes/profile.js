const express = require('express');
const router = express.Router();
const { check } = require('express-validator');

const profile_controller = require('../controllers/profile');
// Profile Controller Routers
router.get('/test', profile_controller.test);

router.get('/createConnections', profile_controller.createConn);

router.get('/savedConnections', profile_controller.login);

router.get('/mymeetups', profile_controller.mymeetups);

router.get('/delete/:id', profile_controller.delete);

router.get('/connection', profile_controller.connection);
// Validation rules
router.post('/connection/save',[
    check('id','ID is not correct').isAlphanumeric(),
    check('topic','Topic is not correct').isAlpha(),
    check('name','Name is not correct').isAlpha(),
    check('details','Details is not correct').isAlpha(),
    check('location','Location is not correct').isAlpha(),
    check('datetime','Date is not correct').isAlpha(),
  ], profile_controller.connection_save);

router.get('/userconnection/save', profile_controller.user_connection_save);

router.get('/viewusers', profile_controller.allusers);

router.get('/userdelete/:id', profile_controller.deleteuser);

router.get('/userdet', profile_controller.userDetail);

module.exports = router;
