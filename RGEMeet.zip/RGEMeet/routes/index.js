const express = require('express');
const router = express.Router();
const { check } = require('express-validator');

const index_controller = require('../controllers/index');
// Index Controller Routers
router.get('/test', index_controller.test);

router.get('/', index_controller.index);

router.get('/index', index_controller.index);

router.get('/about', index_controller.about);

router.get('/contact', index_controller.contact);

router.get('/logout', index_controller.logout);

router.get('/connections', index_controller.connections);

router.get('/connection', index_controller.connection);

router.get('/addnewconnection', index_controller.add_new_connection);

router.get('/signup', index_controller.signup_user);
// Validation rules
router.post('/registered',[
    check('firstName','First Name should be in Alphabets').isAlpha(),
    check('lastName','Last Name should be in Alphabets').isAlpha(),
    check('emailAddress','Email is not correct').isEmail(),
    check('city','City should be in Alphabets').isAlpha(),
    check('state','State should be in Alphabets').isAlpha(),
    check('zipCode','Zip Code should be Numeric').isNumeric(),
    check('country','Country should be in Alphabets').isAlpha(),
    check('password', 'Password is required').not().isEmpty()
  ], index_controller.registered);

router.get('/login', index_controller.login_user);

router.post('/signin', index_controller.signIn);


module.exports = router;
