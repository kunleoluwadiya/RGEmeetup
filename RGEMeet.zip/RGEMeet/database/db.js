var mongoose = require('mongoose');

// Local DB Connection String
module.exports =  mongoose.connect('mongodb://127.0.0.1:27017/assignment', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

//Live DB Connection String
// module.exports = mongoose.connect('');